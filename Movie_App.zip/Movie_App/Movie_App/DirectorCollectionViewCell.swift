//
//  DirectorCollectionViewCell.swift
//  Movie_App
//
//  Created by sara ayed albogami on 29/08/1444 AH.
//

//import UIKit
//
//class DirectorCollectionViewCell: UICollectionViewCell {
//    
//    @IBOutlet weak var dirName: UILabel!
//    @IBOutlet weak var dirImage: UIImageView!
//    
//  
//}
