//
//  DetailsCollectionViewCell.swift
//  Movie_App
//
//  Created by sara ayed albogami on 26/08/1444 AH.
//

import UIKit

class DetailsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var reviewerName: UILabel!
    @IBOutlet weak var Date: UILabel!
    @IBOutlet weak var reviewerText: UILabel!
    @IBOutlet weak var reviewerPhoto: UIImageView!
    @IBOutlet weak var reviewerRate: UILabel!
}

