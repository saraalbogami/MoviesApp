//
//  StarCollectionViewCell.swift
//  Movie_App
//
//  Created by sara ayed albogami on 29/08/1444 AH.
//

//import UIKit
//
//class StarCollectionViewCell: UICollectionViewCell {
//    
//    @IBOutlet weak var StarName: UILabel!
//    
//    @IBOutlet weak var StarPhoto: UIImageView!
//}
