//
//  DetailsData.swift
//  Movie_App
//
//  Created by sara ayed albogami on 28/08/1444 AH.
//
//


import Foundation


struct MoviesData: Codable {
let id, movieName: String
let moviePoster: String
let movieStory: String
let movieDuration: String
let movieGenres: [String]
let movieWatcherType: String
let movieIMDBRate: Double
let movieLanguage: String


enum CodingKeys: String, CodingKey {
    case id
    case movieName = "movie_name"
    case moviePoster = "movie_poster"
    case movieStory = "movie_story"
    case movieDuration = "movie_duration"
    case movieGenres = "movie_genres"
    case movieWatcherType = "movie_watcher_type"
    case movieIMDBRate = "movie_IMDb_rate"
    case movieLanguage = "movie_language"
   
}
}

struct Actors: Codable {
let id, actorName: String
let actorImage: String

enum CodingKeys: String, CodingKey {
    case id
    case actorName = "actor_name"
    case actorImage = "actor_image"
}
}

//typealias Welcome = [Actors]

struct Director: Codable {
let id, directorName: String
let directorImage: String

enum CodingKeys: String, CodingKey {
    case id
    case directorName = "director_name"
    case directorImage = "director_image"
}
}


struct Reviewer: Codable {
    let id: String
    let rate: Int
    let reviewText, createdAt, movieID, userID: String

    enum CodingKeys: String, CodingKey {
        case id, rate
        case reviewText = "review_text"
        case createdAt = "created_at"
        case movieID = "movie_id"
        case userID = "user_id"
    }
}



















// MARK: - WelcomeElement


//    // MARK: - Welcome
//    struct Welcome: Codable {
//        let info: Info
//        let item: [WelcomeItem]
//        let event: [Event]
//        let variable: [HeaderElement]
//    }
//
//    // MARK: - Event
//    struct Event: Codable {
//        let listen: String
//        let script: Script
//    }
//
//    // MARK: - Script
//    struct Script: Codable {
//        let type: String
//        let exec: [String]
//    }
//
//    // MARK: - Info
//    struct Info: Codable {
//        let postmanID, name: String
//        let schema: String
//        let exporterID: String
//
//        enum CodingKeys: String, CodingKey {
//            case postmanID = "_postman_id"
//            case name, schema
//            case exporterID = "_exporter_id"
//        }
//    }
//
//    // MARK: - WelcomeItem
//    struct WelcomeItem: Codable {
//        let name: String
//        let item: [ItemItem]
//    }
//
//    // MARK: - ItemItem
//    struct ItemItem: Codable {
//        let name: String
//        let request: Request
//        let response: [Response]
//        let protocolProfileBehavior: ProtocolProfileBehavior?
//    }
//
//    // MARK: - ProtocolProfileBehavior
//    struct ProtocolProfileBehavior: Codable {
//        let disableBodyPruning, followRedirects: Bool
//    }
//
//    // MARK: - Request
//    struct Request: Codable {
//        let method: Method
//        let header: [JSONAny]
//        let url: RequestURL
//        let body: Body?
//    }
//
//    // MARK: - Body
//    struct Body: Codable {
//        let mode: Mode
//        let raw: String
//        let options: Options
//    }
//
//    enum Mode: String, Codable {
//        case raw = "raw"
//    }
//
//    // MARK: - Options
//    struct Options: Codable {
//        let raw: Raw
//    }
//
//    // MARK: - Raw
//    struct Raw: Codable {
//        let language: Language
//    }
//
//    enum Language: String, Codable {
//        case json = "json"
//    }
//
//    enum Method: String, Codable {
//        case methodGET = "GET"
//        case post = "POST"
//        case put = "PUT"
//    }
//
//    // MARK: - RequestURL
//    struct RequestURL: Codable {
//        let raw: String
//        let host: [Host]
//        let path: [String]
//    }
//
//    enum Host: String, Codable {
//        case url = "{{url}}"
//    }
//
//    // MARK: - Response
//    struct Response: Codable {
//        let name: String
//        let originalRequest: OriginalRequest
//        let postmanPreviewlanguage: Language?
//        let header: [HeaderElement]?
//        let cookie: [JSONAny]
//        let body: String
//        let status: String?
//        let code: Int?
//
//        enum CodingKeys: String, CodingKey {
//            case name, originalRequest
//            case postmanPreviewlanguage = "_postman_previewlanguage"
//            case header, cookie, body, status, code
//        }
//    }
//
//    // MARK: - HeaderElement
//    struct HeaderElement: Codable {
//        let key: NameEnum
//        let value: String
//        let name: NameEnum?
//        let description: String?
//        let type: TypeEnum?
//    }
//
//    enum NameEnum: String, Codable {
//        case accessControlAllowOrigin = "Access-Control-Allow-Origin"
//        case connection = "Connection"
//        case contentLength = "Content-Length"
//        case contentType = "Content-Type"
//        case url = "url"
//    }
//
//    enum TypeEnum: String, Codable {
//        case string = "string"
//        case text = "text"
//    }
//
//    // MARK: - OriginalRequest
//    struct OriginalRequest: Codable {
//        let method: Method
//        let header: [HeaderElement]
//        let url: OriginalRequestURL
//        let body: Body?
//    }
//
//    // MARK: - OriginalRequestURL
//    struct OriginalRequestURL: Codable {
//        let raw: String
//        let urlProtocol: ProtocolEnum?
//        let host, path: [String]
//        let variable: [URLVariable]?
//
//        enum CodingKeys: String, CodingKey {
//            case raw
//            case urlProtocol = "protocol"
//            case host, path, variable
//        }
//    }
//
//    enum ProtocolEnum: String, Codable {
//        case https = "https"
//    }
//
//    // MARK: - URLVariable
//    struct URLVariable: Codable {
//        let key: PurpleKey
//        let value: String
//    }
//
//    enum PurpleKey: String, Codable {
//        case id = "id"
//        case movieID = "movie_id"
//        case userID = "user_id"
//    }
//
//    // MARK: - Encode/decode helpers
//
//    class JSONNull: Codable, Hashable {
//
//        public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
//            return true
//        }
//
//        public var hashValue: Int {
//            return 0
//        }
//
//        public init() {}
//
//        public required init(from decoder: Decoder) throws {
//            let container = try decoder.singleValueContainer()
//            if !container.decodeNil() {
//                throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
//            }
//        }
//
//        public func encode(to encoder: Encoder) throws {
//            var container = encoder.singleValueContainer()
//            try container.encodeNil()
//        }
//    }
//
//    class JSONCodingKey: CodingKey {
//        let key: String
//
//        required init?(intValue: Int) {
//            return nil
//        }
//
//        required init?(stringValue: String) {
//            key = stringValue
//        }
//
//        var intValue: Int? {
//            return nil
//        }
//
//        var stringValue: String {
//            return key
//        }
//    }
//
//    class JSONAny: Codable {
//
//        let value: Any
//
//        static func decodingError(forCodingPath codingPath: [CodingKey]) -> DecodingError {
//            let context = DecodingError.Context(codingPath: codingPath, debugDescription: "Cannot decode JSONAny")
//            return DecodingError.typeMismatch(JSONAny.self, context)
//        }
//
//        static func encodingError(forValue value: Any, codingPath: [CodingKey]) -> EncodingError {
//            let context = EncodingError.Context(codingPath: codingPath, debugDescription: "Cannot encode JSONAny")
//            return EncodingError.invalidValue(value, context)
//        }
//
//        static func decode(from container: SingleValueDecodingContainer) throws -> Any {
//            if let value = try? container.decode(Bool.self) {
//                return value
//            }
//            if let value = try? container.decode(Int64.self) {
//                return value
//            }
//            if let value = try? container.decode(Double.self) {
//                return value
//            }
//            if let value = try? container.decode(String.self) {
//                return value
//            }
//            if container.decodeNil() {
//                return JSONNull()
//            }
//            throw decodingError(forCodingPath: container.codingPath)
//        }
//
//        static func decode(from container: inout UnkeyedDecodingContainer) throws -> Any {
//            if let value = try? container.decode(Bool.self) {
//                return value
//            }
//            if let value = try? container.decode(Int64.self) {
//                return value
//            }
//            if let value = try? container.decode(Double.self) {
//                return value
//            }
//            if let value = try? container.decode(String.self) {
//                return value
//            }
//            if let value = try? container.decodeNil() {
//                if value {
//                    return JSONNull()
//                }
//            }
//            if var container = try? container.nestedUnkeyedContainer() {
//                return try decodeArray(from: &container)
//            }
//            if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self) {
//                return try decodeDictionary(from: &container)
//            }
//            throw decodingError(forCodingPath: container.codingPath)
//        }
//
//        static func decode(from container: inout KeyedDecodingContainer<JSONCodingKey>, forKey key: JSONCodingKey) throws -> Any {
//            if let value = try? container.decode(Bool.self, forKey: key) {
//                return value
//            }
//            if let value = try? container.decode(Int64.self, forKey: key) {
//                return value
//            }
//            if let value = try? container.decode(Double.self, forKey: key) {
//                return value
//            }
//            if let value = try? container.decode(String.self, forKey: key) {
//                return value
//            }
//            if let value = try? container.decodeNil(forKey: key) {
//                if value {
//                    return JSONNull()
//                }
//            }
//            if var container = try? container.nestedUnkeyedContainer(forKey: key) {
//                return try decodeArray(from: &container)
//            }
//            if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key) {
//                return try decodeDictionary(from: &container)
//            }
//            throw decodingError(forCodingPath: container.codingPath)
//        }
//
//        static func decodeArray(from container: inout UnkeyedDecodingContainer) throws -> [Any] {
//            var arr: [Any] = []
//            while !container.isAtEnd {
//                let value = try decode(from: &container)
//                arr.append(value)
//            }
//            return arr
//        }
//
//        static func decodeDictionary(from container: inout KeyedDecodingContainer<JSONCodingKey>) throws -> [String: Any] {
//            var dict = [String: Any]()
//            for key in container.allKeys {
//                let value = try decode(from: &container, forKey: key)
//                dict[key.stringValue] = value
//            }
//            return dict
//        }
//
//        static func encode(to container: inout UnkeyedEncodingContainer, array: [Any]) throws {
//            for value in array {
//                if let value = value as? Bool {
//                    try container.encode(value)
//                } else if let value = value as? Int64 {
//                    try container.encode(value)
//                } else if let value = value as? Double {
//                    try container.encode(value)
//                } else if let value = value as? String {
//                    try container.encode(value)
//                } else if value is JSONNull {
//                    try container.encodeNil()
//                } else if let value = value as? [Any] {
//                    var container = container.nestedUnkeyedContainer()
//                    try encode(to: &container, array: value)
//                } else if let value = value as? [String: Any] {
//                    var container = container.nestedContainer(keyedBy: JSONCodingKey.self)
//                    try encode(to: &container, dictionary: value)
//                } else {
//                    throw encodingError(forValue: value, codingPath: container.codingPath)
//                }
//            }
//        }
//
//        static func encode(to container: inout KeyedEncodingContainer<JSONCodingKey>, dictionary: [String: Any]) throws {
//            for (key, value) in dictionary {
//                let key = JSONCodingKey(stringValue: key)!
//                if let value = value as? Bool {
//                    try container.encode(value, forKey: key)
//                } else if let value = value as? Int64 {
//                    try container.encode(value, forKey: key)
//                } else if let value = value as? Double {
//                    try container.encode(value, forKey: key)
//                } else if let value = value as? String {
//                    try container.encode(value, forKey: key)
//                } else if value is JSONNull {
//                    try container.encodeNil(forKey: key)
//                } else if let value = value as? [Any] {
//                    var container = container.nestedUnkeyedContainer(forKey: key)
//                    try encode(to: &container, array: value)
//                } else if let value = value as? [String: Any] {
//                    var container = container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key)
//                    try encode(to: &container, dictionary: value)
//                } else {
//                    throw encodingError(forValue: value, codingPath: container.codingPath)
//                }
//            }
//        }
//
//        static func encode(to container: inout SingleValueEncodingContainer, value: Any) throws {
//            if let value = value as? Bool {
//                try container.encode(value)
//            } else if let value = value as? Int64 {
//                try container.encode(value)
//            } else if let value = value as? Double {
//                try container.encode(value)
//            } else if let value = value as? String {
//                try container.encode(value)
//            } else if value is JSONNull {
//                try container.encodeNil()
//            } else {
//                throw encodingError(forValue: value, codingPath: container.codingPath)
//            }
//        }
//
//        public required init(from decoder: Decoder) throws {
//            if var arrayContainer = try? decoder.unkeyedContainer() {
//                self.value = try JSONAny.decodeArray(from: &arrayContainer)
//            } else if var container = try? decoder.container(keyedBy: JSONCodingKey.self) {
//                self.value = try JSONAny.decodeDictionary(from: &container)
//            } else {
//                let container = try decoder.singleValueContainer()
//                self.value = try JSONAny.decode(from: container)
//            }
//        }
//
//        public func encode(to encoder: Encoder) throws {
//            if let arr = self.value as? [Any] {
//                var container = encoder.unkeyedContainer()
//                try JSONAny.encode(to: &container, array: arr)
//            } else if let dict = self.value as? [String: Any] {
//                var container = encoder.container(keyedBy: JSONCodingKey.self)
//                try JSONAny.encode(to: &container, dictionary: dict)
//            } else {
//                var container = encoder.singleValueContainer()
//                try JSONAny.encode(to: &container, value: self.value)
//            }
//        }
//    }
//
//
