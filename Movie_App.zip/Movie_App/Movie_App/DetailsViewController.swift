//
//  ViewController.swift
//  Movie_App
//
//  Created by sara ayed albogami on 24/08/1444 AH.
//

import UIKit

extension UIImageView {
    func downloaded(from url: URL, contentMode mode: ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    func downloaded(from link: String, contentMode mode: ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}



class DetailsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    

    @IBOutlet weak var tableView: UITableView!
    
    
   var arrdata = [MoviesData]()
    //
    var movie : MoviesData?
    
    //var movieId : String
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       // tableView.contentInsetAdjustmentBehavior = .never
        getdata()
        tableView.delegate = self
        tableView.dataSource = self
        
    
    }

    func getdata(){
        
            let baseURL = "https://11d9528c-d6bd-49b7-87cb-232cc0a0e490.mock.pstmn.io/movies"
//            let url = URL(string: baseURL+"/movies")!
            
//            let task =  URLSession.shared.dataTask(with: url) { (data, response, error) in
//                do{if error == nil{
//                    self.arrdata = try JSONDecoder().decode([MoviesData].self, from: data!)
//
//                    for mainarr in self.arrdata{
//                        //print(mainarr.name,":",mainarr.capital,":",mainarr.alpha3Code)
//                        DispatchQueue.main.async {
//                            self.tableView.reloadData()
//                        }
//
//                    }
//                }
//
//                }catch{
//                    print("Error in get json data\(error)")
//                }
//
//            }
//            task.resume()
        let task = URLSession.shared.dataTask(with: URL(string:baseURL)!,completionHandler: { data, response, error in
                  
                  guard let data = data, error == nil else {
                      print("somthing went wrong \(error?.localizedDescription)")
                      print(data ?? "no data ")
                      return
                  }
            
            if let response = response {
                print(response)

            }
              
              do{
                  // have data
                  self.arrdata = try JSONDecoder().decode([MoviesData].self, from: data)
                  DispatchQueue.main.async {
                      self.tableView.reloadData()
                  }
                  
              }catch{
                 print("failed to convert")
              }

            print(self.arrdata)

           

          })
          
          task.resume()
         
          
          
        
      }
        
        
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : DetailsTableViewCell = tableView.dequeueReusableCell(withIdentifier: "detailsCell", for: indexPath) as! DetailsTableViewCell
       
//        let imagetoString = arrdata[indexPath.row].moviePoster
//        if let url = URL(string: imagetoString){
//        if let data = try? Data(contentsOf: url) {
//            cell.MoviePhoto.image = UIImage(data: data)
//        }
//        }
//        //    cell.MoviePhoto.image = UIImage(named: arrdata[indexPath.row].moviePoster)
//
////        let urlimg = "https://cdn.shopify.com/s/files/1/0057/3728/3618/products" + (arrdata[indexPath.row].moviePoster)
////        cell.MoviePhoto.downloaded(from: urlimg)
//            //        cell.DirName.text = arrdata[indexPath.row].directorName
//                // cell.DirPhoto.image = UIImage(named: arrdata[indexPath.row].directorImage)
//            cell.MovieName.text = arrdata[indexPath.row].movieName
//            cell.MovieDuration.text = arrdata[indexPath.row].movieDuration
//            cell.MovieLanguage.text = arrdata[indexPath.row].movieLanguage
//         //   cell.MovieGenre.text = String(arrdata[indexPath.row].movieGenres)
//            cell.MovieAge.text = arrdata[indexPath.row].movieWatcherType
//            cell.MovieStory.text = arrdata[indexPath.row].movieStory
//            cell.MovieRating.text =  String(arrdata[indexPath.row].movieIMDBRate)
        
        let imagetoString = movie?.moviePoster
        if let url = URL(string: imagetoString ?? "https://cdn.shopify.com/s/files/1/0057/3728/3618/products/9f22e23817c4accbf052e0f91a2b7821_156f8e4f-814c-4dcb-896d-0b077053cd51_500x749.jpg?v=1573593734"){
            if let data = try? Data(contentsOf: url) {
                cell.MoviePhoto.image = UIImage(data: data)
            }
            }
       // cell.MovieName.text = movie?.movieName
       // cell.MovieGenre.text = movie?.movieGenres
       // cell.MovieDuration.text = movie?.movieDuration
       // cell.MovieLanguage.text = movie?.movieLanguage
      //  cell.MovieAge.text = movie?.movieWatcherType
       // cell.MovieRating.text = movie?.movieIMDBRate
       // cell.MovieStory.text = movie?.movieStory
            
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    1600
        
    }
    
    @IBAction func MovieShare_Click(_ sender: Any){

        let activityVC = UIActivityViewController(activityItems: ["developer.apple.com"], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view

        self.present(activityVC, animated: true, completion: nil)
    }
}

