//
//  DetailsTableViewCell.swift
//  Movie_App
//
//  Created by sara ayed albogami on 24/08/1444 AH.
//

import UIKit



class DetailsTableViewCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource {
 
    var array: Director?
    
    @IBOutlet weak var CollectionView: UICollectionView!
    @IBOutlet weak var ReviewerRating: UILabel!
    @IBOutlet weak var colStarCell: UICollectionView!
    @IBOutlet weak var colDirCell: UICollectionView!
    @IBOutlet weak var MovieRating: UILabel!
    @IBOutlet weak var MovieStory: UILabel!
    @IBOutlet weak var MovieAge: UILabel!
    @IBOutlet weak var MovieGenre: UILabel!
    @IBOutlet weak var MovieLanguage: UILabel!
    @IBOutlet weak var MovieDuration: UILabel!
    @IBOutlet weak var MovieSave: UIButton!
    @IBOutlet weak var MovieShare: UIButton!
    @IBOutlet weak var MovieName: UILabel!
    @IBOutlet weak var MoviePhoto: UIImageView!
    @IBOutlet weak var shadow: UIImageView!
    
    var Arrdata = [Reviewer]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        CollectionView.delegate = self
        CollectionView.dataSource = self
        Getdata()
        
        
    }

    func Getdata(){
        
        let baseURL = "https://11d9528c-d6bd-49b7-87cb-232cc0a0e490.mock.pstmn.io"
        let url = URL(string: baseURL+"/reviews/8836123A-AF72-4409-B563-8625904C2D7E")!
        
      let task =  URLSession.shared.dataTask(with: url) { (data, response, error) in
            do{if error == nil{
                self.Arrdata = try JSONDecoder().decode([Reviewer].self, from: data!)
                
                for mainarr in self.Arrdata{
                    //print(mainarr.name,":",mainarr.capital,":",mainarr.alpha3Code)
                    DispatchQueue.main.async {
                         self.CollectionView.reloadData()
                    }
                   
                }
                }
            
            }catch{
                print("Error in get json data\(error)")
            }
          print(self.Arrdata.count)
        }
        task.resume()
    }
    
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return Arrdata.count
        print(Arrdata.count)

    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell :DetailsCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "colReviewCell", for: indexPath) as! DetailsCollectionViewCell
        cell.reviewerName.text = Arrdata[indexPath.row].userID
        cell.reviewerText.text = Arrdata[indexPath.row].reviewText
        cell.Date.text = Arrdata[indexPath.row].createdAt
        cell.reviewerRate.text = String(Arrdata[indexPath.row].rate)
        return cell
    }

    @IBAction func MovieSave_Click(_ sender: UIButton){
        
        if MovieSave.tag == 0 {
            MovieSave.setImage(UIImage(systemName: "bookmark"), for: .normal)
            MovieSave.tag = 1
        }
        else
        {
            MovieSave.setImage(UIImage(systemName: "bookmark.fill"), for: .normal)
            MovieSave.tag = 0
        }
    }
    
    
}
